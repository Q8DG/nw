# -*- coding: utf-8 -*-
"""
Spyder Editor
This is a temporary script file.
"""

import os

def imageDecode(f,fn):
    dat_read = open(f, "rb")
    out = output_path + fn + ".jpg"  #FF对应为 jpg，89对应为png
    png_write = open(out, "wb")
    for now in dat_read:
        for nowByte in now:
            newByte = nowByte ^ 0x61 #修改为自己的解密码（例：9E FF的异或的十六进制为0x61）
            png_write.write(bytes([newByte]))
    dat_read.close()
    png_write.close()

def findFile(f):
    fsinfo = os.listdir(f)
    for fn in fsinfo:
        temp_path = os.path.join(f, fn)
        if not os.path.isdir(temp_path):
            print('文件路径: {}' .format(temp_path))
            imageDecode(temp_path,fn)
        else:
            ...

path = r'D:/Documents/Tencent/WeChat Files/wxid_fi9sn6z7hf1m22/FileStorage/Image/2021-03/'  #建议把\替换为/，因为\有时候会被错误识别为转义符，无法找到正确的路径
output_path = r'D:/Image_out/2021-03/'  #要保证这个路径存在，建议新建一个文件夹命名为Decoded
findFile(path)
